#include <stdio.h>



int mp3init(void)
{
        int result=0;
        return result;
        }
